
package metier;


public class Compte {
   public int code ;
   public float solde;
   public static int nbComptes=0;

   /* creation de compte sachant que le nbCompte initiale de compte est 0*/
   public Compte (float s){
       ++nbComptes; //a chaques fois que cree un compte j'incremente le nbCompte 
       code = nbComptes;
       solde =s;
       }
   
    public void verser(float mt){
       solde = + mt;
       }
    public void retirer(float mt){
       solde = - mt;
       }
    public String toString(){
       return("Code ="+code +" mon Solde="+solde );
       }

    public int getCode() {
        return code;
    }

    public float getSolde() {
        return solde;
    }

    public static int getNbComptes() {
        return nbComptes;
    }
    
    
}
