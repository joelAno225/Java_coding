
package a;

public abstract class Fruits {
    protected int poids;
    public Fruits (){
        System.out.println("Creation d'un fruits");
    }
    public void affiche(){
        System.out.println("C'est un fruit");
    }
   
}
