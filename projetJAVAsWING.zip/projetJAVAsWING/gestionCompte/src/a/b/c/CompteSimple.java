
package a.b.c;

public final class CompteSimple extends Compte{
   private int decouvert;

      public CompteSimple(int decouvert, int code, float solde) {
         super(code, solde);
         this.decouvert = decouvert;
    }
   /*la classe compte simple herite de la methode retiré mais cette methode
     n'est pas prise en compte au niveau de decouvert 
     on redefinie la methode retirer() car elle n'est pas prise en compte a ce  niveau */
      
      @Override
      public void retirer (float mt){
         if (mt<solde+decouvert) solde = - decouvert;
         
         }
      @Override
      public void afficher() {
          System.out.println("C'est un compte simple ");
         
    }
}
      
    

