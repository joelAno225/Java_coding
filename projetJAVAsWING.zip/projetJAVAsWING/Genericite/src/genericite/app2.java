
package Test;

public class app2 {
    public static void main(String[] args){
       Triple<String,Double> o = new Triple<String,Double>("A","B",7.3);
       System.out.println(o.getA());
       System.out.println(o.getB());
       System.out.println(o.getC());
       
     
}
    
}
