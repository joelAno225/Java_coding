
package gestiondecomptebanquaire;


public class CompteMetier {
//cette classe represente la couche metier 
    private int  code ;
    private float solde;

    public CompteMetier(int code, float solde) {
        this.code = code;
        this.solde = solde;
    }

    public void verser(float mt){
        solde = solde+ mt;
    }
    public void retirer (float mt)throws SoldeInsuffisantException,NegException{
      if (solde<mt) throw new SoldeInsuffisantException("Solde Insuffisant");//Execption surveillé
      if (mt<0) throw new NegException("Solde negatif");   
      solde = solde -mt ;
    }

    public float getSolde() {
        return solde;
    }
   
}
