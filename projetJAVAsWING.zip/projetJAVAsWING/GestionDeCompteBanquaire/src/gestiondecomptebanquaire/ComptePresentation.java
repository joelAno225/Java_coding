
package gestiondecomptebanquaire;


import java.util.InputMismatchException;
import java.util.Scanner;

public class ComptePresentation {

    public static void main(String[] args) throws NegException {
     try{
         Scanner clavier = new Scanner(System.in);
         System.out.print("Code :"); int c = clavier.nextInt();
         if(c<=0){System.out.println("Entreé une valeur positive");
        }
        else
        {
        System.out.print("Solde:") ;float s = clavier.nextFloat();

         CompteMetier cp = new CompteMetier(c, s);
         System.out.println("Montant à verser :");
         float mt1 =clavier.nextFloat();
         cp.verser(mt1);
      
         System.out.println("Montant à retirer :");
         float mt2 =clavier.nextFloat();
         System.out.println("le Solde est :"+cp.getSolde());
         cp.retirer(mt2);
        }
         
        } catch (SoldeInsuffisantException e){
             System.out.println(e.getMessage()); //le try-catch est mieux au niveau de la presentation //on affiche le mgs pck onest dans partie presentation //Exception pck on a plusieures exceptionj qui affiche le meeme message      
        }  
          catch(NegException e) {
             System.out.println(e.getMessage());
        }
          catch(InputMismatchException e){
             System.out.println("Probleme de saisir ");
        }
        finally {
           System.out.println("Merci pour votre fidelité "); 
        }
    }
}