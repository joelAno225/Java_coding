
package comptebanquairegenericite;


public class Bank {

// creation d'un systeme de transfert d'argent d'un compte A-B via l'objet Bank 

   private String nomBank;

    public Bank(String nomBank) {
        this.nomBank = nomBank;
    }

    public String getNomBank() {
        return nomBank;
    }

    public void transfert(compteBancaire<String> sourceCompte, compteBancaire<String> receptionCompte, int solde) {
        if(sourceCompte.getSolde()>=solde){
        //Transaction possible 
        sourceCompte.retiterArgent(solde);
        sourceCompte.ajouteArgent(solde);
        System.out.println(sourceCompte.getSolde()+ "a envoyer"+solde+" "+sourceCompte.getDevise()+"à "+receptionCompte.getProprietaire()); 
    }
    else
    {   System.err.println("Transaction impossible ! la "+sourceCompte.getProprietaire()+"n'a pas les fonds ");
    }
    }
}