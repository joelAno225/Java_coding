
package voiture;

public class Audi extends Car {

    public Audi(String model, String fuel, int numberGear, boolean auto) {
        super(model, fuel, numberGear, auto);
    }
     
    
}
