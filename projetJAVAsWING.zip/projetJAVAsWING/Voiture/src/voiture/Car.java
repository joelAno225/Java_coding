
package voiture;

public class Car {

// fuel = caburant, Gear =equipement
  
   private String model;
   private String fuel;
   private int numberGear;
   private boolean auto;

    public Car(String model, String fuel, int numberGear, boolean auto) {
        this.model = model;
        this.fuel = fuel;
        this.numberGear = numberGear;
        this.auto = auto;
    }

    public String getModel(){ return model;}
    public void setModel(String model){this.model=model;}
    public String getFuel(){return fuel;}
    public void setFuel(String fuel){this.fuel=fuel;}
    public int getNumberGear(){return numberGear ;}
    public void setNumberGear(int numberGear){this.numberGear=numberGear;}
    public boolean isAuto(){return auto;}
    public void setAuto(boolean auto){this.auto=auto;}
}
