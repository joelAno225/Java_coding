package tp3;

import metier.Compte;

public class TP3 {

    public static void main(String[] args) {
        Compte c1 = new Compte(10000);
        Compte c2 = new Compte(20000);
        Compte c3 = new Compte(80000);
        System.out.println(c1.toString());
        System.out.println(c2.toString());
        System.out.println(c3.toString());
        System.out.println("NBC=" + Compte.getNbComptes());
        System.out.println(c1.getCode());
        System.out.println(c1.getSolde());
        c3.verser(3000);
        c1.retirer(2000);
        System.out.println(c1.toString());
        System.out.println(c3.toString());
    }

}
