
package a;

public class Pomme extends Fruits{
     
    public Pomme(int p){
       this.poids = p;
       System.out.println("Création d'une pomme de "+poids+"grammes");
    }
    // redifinition de la methode affiche 

  @Override
     public void affiche(){
      System.out.println("C'est un fruit");
    }
     public void affichePoids(){
        System.out.println("C'est une pomme de poids" +poids);
    }
}
