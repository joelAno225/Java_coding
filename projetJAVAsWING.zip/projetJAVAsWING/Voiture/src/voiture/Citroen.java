
package voiture;

public class Citroen extends Car{

    public Citroen(String model, String fuel, int numberGear, boolean auto) {
        super(model, fuel, numberGear, auto);
    }
   
    
}
