
package io;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class IO {

    public static void main(String[] args) throws IOException {
    //cree et ecrire dans un fichier javaTXT.txt
        FileWriter fw = new FileWriter(new File("javaTXT"));
        fw.write("Joel;10;A1");
        fw.write("Job;3;A2");
        fw.write("Joel;11;B2");
        fw.flush();
        fw.close();      
    }
    
}
