
package metier;

/*le but c est de cree une application pour manipuler les comptes */

public class Compte {
    private int code;
    private float solde;
/*utilisons un contructeur : le contructeur porte tj le meme nom que la classe */
    public Compte(int c ,float s){
          code = c ;solde = s;
    }
/* les methodes */
    public void verser(float mt){
         solde = solde +mt ;
    }
    public void retirer(float mt){
         solde = solde-mt ;
    }
    public String toString(){
          return("Code="+code+ "Solde="+solde);
    }   
}
