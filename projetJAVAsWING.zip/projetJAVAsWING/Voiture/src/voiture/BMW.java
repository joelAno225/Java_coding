
package voiture;

public class BMW extends Car{

    public BMW(String model, String fuel, int numberGear, boolean auto) {
        super(model, fuel, numberGear, auto);
    }
    
    
}
