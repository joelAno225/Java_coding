
package a;

public class Orange extends Fruits{
     
    public Orange(int p){
       this.poids = p;
       System.out.println("Création d'une orange de "+poids+"grammes");
    }
    // redifinition de la methode affiche 

  @Override
     public void affiche(){
      System.out.println("C'est un fruit");
    }
     public void affichePoids(){
        System.out.println("C'est une pomme de poids" +poids);
    }
}