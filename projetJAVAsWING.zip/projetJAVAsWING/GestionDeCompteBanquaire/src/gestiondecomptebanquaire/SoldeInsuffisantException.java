
package gestiondecomptebanquaire;

//Définition d'une exception surveillée personnalisée .

public class SoldeInsuffisantException extends Exception {

    public SoldeInsuffisantException(String message) {
        super(message);
    }       
}
