
package genericite;

public class Triple<T,T2> extends Couple<T>{
   private T2 c;

public Triple() {

    }


public Triple(T2 c, T a, T b) {
        super(a, b);
        this.c = c;
    }

public T2 getC() {
        return c;
    }

public void setC(T2 c) {
        this.c = c;
    }

    
}
