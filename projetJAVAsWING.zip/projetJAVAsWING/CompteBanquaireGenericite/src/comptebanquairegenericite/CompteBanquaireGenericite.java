
package comptebanquairegenericite;


public class CompteBanquaireGenericite{

    public static void main(String[] args) {
      compteBancaire<String> monSolde = new compteBancaire<String>("joel",100,"$");
      monSolde.soldeActuel();


      compteBancaire <String> monSolde2 = new compteBancaire<String>("Ano",10,"$");
      monSolde2.soldeActuel();

      Bank bank =new Bank("ElephantCryptoBank");
      bank.transfert(monSolde,monSolde2,25);
       
      monSolde.soldeActuel();
      monSolde2.soldeActuel();
    } 
    
}
