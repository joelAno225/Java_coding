
package comptebanquairegenericite;
   //Creation d'une classe genericite .

public class compteBancaire <T>{

   //creation d'un systeme de gestion de fond simple 

   private String proprietaire;
   private double solde;//montant actuel du compte 
   private T devise ;

   public compteBancaire(String proprietaire, double solde, T devise) {
        this.proprietaire = proprietaire;
        this.solde = solde;
        this.devise = devise;
    }
   
   // creation de methode pour recuperer les infos

    public String getProprietaire() {
        return proprietaire;
    }

    public double getSolde() {
        return solde;
    }

    public T getDevise() {
        return devise;
    }


    public void ajouteArgent(int solde){
       this.solde+=solde;
    }

    public void retiterArgent(int solde){
       this.solde-=solde;
    }
   
    public void soldeActuel(){
        System.out.println("Vous avez actuellement"+solde+"  "+devise+"sur votre compte Banquaire");
    }
    
    

   
    
}
