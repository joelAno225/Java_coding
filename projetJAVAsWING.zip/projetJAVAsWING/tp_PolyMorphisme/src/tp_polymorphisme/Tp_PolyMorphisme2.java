package tp_polymorphisme;

import a.Fruits;
import a.Orange;
import a.Pomme;

import java.util.ArrayList;
import java.util.List;


public class Tp_PolyMorphisme2 {

    public static void main(String[] args) {
       //utilisation des collections

       List<Fruits> lesFruits = new ArrayList<Fruits>();
       lesFruits.add(new Pomme(40));
       lesFruits.add(new Orange(40));
       lesFruits.add(new Pomme(45));
    }
     //for (Fruits f:lesFruits){
     //  f.affiche();
    } 
    
    for (int i=0;i<lesFruits.size();i++){
        lesFruits.get(i).affiche();
    }
}