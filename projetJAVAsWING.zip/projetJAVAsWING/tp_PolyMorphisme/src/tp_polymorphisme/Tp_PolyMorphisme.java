
package tp_polymorphisme;

import a.Fruits;
import a.Orange;
import a.Pomme;

public class Tp_PolyMorphisme {

 
   public static void main(String[] args){

      Fruits[] lesFruits = new Fruits[3];
      lesFruits [0] = new Pomme(50);
      lesFruits [1] = new Orange(80); 
      lesFruits [2] = new Pomme(20);  
      
    }
      for (Fruits f :lesFruits{
         f.affiche());

}

}
