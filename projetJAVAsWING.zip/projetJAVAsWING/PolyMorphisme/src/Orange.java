
public class Orange  extends Fruit{
    public Orange(int p){
      poids = p;
      System.out.println("Creation d'une Orange "+poids +"gramme(s)");
    }
  @Override
    public void  affiche() {
      System.out.println("C'est une Orange");
    }     
    public void affichePoids(){
        System.out.println("le poids de l'Orange est " +poids + "gramme(s)");
    }



}
