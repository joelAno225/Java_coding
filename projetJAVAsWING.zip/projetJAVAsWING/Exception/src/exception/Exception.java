
package exception;

import java.util.Scanner;

public class Exception {

   
    public static void main(String[] args) {
        Scanner clavier = new Scanner(System.in);
        System.out.print("A :");int a=clavier.nextInt();
        System.out.print("B :");int b=clavier.nextInt();
        
        int c=0;
        try {
             c = a/b;
        } 
        catch(ArithmeticException e) {
            //System.out.println("div par 0");
            //System.out.println(e.getMessage()); 
            //System.out.println(e.toString()); 
            e.printStackTrace();
        }
       
        System.out.println("C :"+c);
    }
    
}
