
package a.b.c;


public abstract class Compte {
    private int code;
    protected float solde;

    public Compte(int code, float solde) {
        this.code = code;
        this.solde = solde;
    }

    public Compte() {
    }
    public abstract void afficher();
    public final void verser(float mt){
      solde = + mt ;
    }
    public void retirer(float mt){
      solde = - mt;
    } 

    public float getSolde() {
        return solde;
    }
    public String toString(){
        return "code="+code + "sold="+solde;
    } 
    


}
