
package tp2; 

import metier.Compte;

public class Application {

 public static void main(String[] args){
      Compte c1 = new Compte(1,5000);
      c1.verser(6000);
      c1.retirer(7000);
      System.out.println(c1.toString());
 }
    
}
