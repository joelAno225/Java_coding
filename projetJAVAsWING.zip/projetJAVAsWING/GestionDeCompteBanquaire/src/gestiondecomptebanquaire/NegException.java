
package gestiondecomptebanquaire;

public class NegException extends Exception{

    public NegException(String message) {
        super(message);
    }

    
   
    
}
