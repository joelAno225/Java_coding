
package test;

import a.b.c.*;


public class App {
   public static void main(String[] args) {
    Compte c = new CompteSimple(500,1,4000); 
    c.verser(5000);
    c.retirer(3000);
       System.out.println(c.toString());
    }
}
