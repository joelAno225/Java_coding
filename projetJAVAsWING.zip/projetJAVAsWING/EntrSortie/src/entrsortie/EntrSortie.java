
package entrsortie;
import java.io.File;

public class EntrSortie {

    public static void main(String[] args) {
  
 //lire le contenue du dossier racine    
       File f = new File("c:/");
       String[] contenue = f.list(); // voir le contenue via liste()
       for (String s:contenue){
           File f2 = new File("c:/"+s); //faisons la diff en repectoire et fiché 
           if (f2.isDirectory())
              System.out.println("Rep :"+s);
           else 
              System.out.println("File :"+s+ "L="+f2.length()+"octé(s)");
        }
    }
    
}
  
    

