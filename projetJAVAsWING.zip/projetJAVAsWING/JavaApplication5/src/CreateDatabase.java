import static java.lang.Character.UnicodeBlock.forName;
import java.sql.*;
public class CreateDatabase
{
	public static void main(String args[])
	{
		try
		{
			//1 charger la classe driver
			class.Character.UnicodeBlock forName = forName("com.mysql.jdbc.Driver");
			
			//2 cree l'objet de connection
			Connection conn = DriveManager.getConnection(
			"jdbc:mysql://localhos:3306?useSSL=false" ,"root" ,"");
			
			//3 cree l'objet statement
			Statement stmt = conn.createStatement();
			
			//4 executer la requete 
			System.out.println("Creation de base de données..");
			stmt.executeUpdate("CREATE DATABASE emp");
			System.out.println("BD cree avec succes");
			
			//5 fermez l'ojet de connexion
			conn.close();
		}
			catch(SQLException e){ 
				System.out.println(e);
		}
	}
}