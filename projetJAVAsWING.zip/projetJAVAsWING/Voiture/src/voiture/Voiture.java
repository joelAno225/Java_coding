
package voiture;



public class Voiture {

    public static void main(String[] args) {
      
      Car[] cars = new Car[5];
       
      cars [0] = new Audi("A1","Diesel",5,false);
      cars [1] = new Citroen("c3","Gazoil",10,true);
      cars [2] = new BMW("z3","Diesel",15,false);   
      cars [3] = new BMW("z3","Diesel",15,false);
      cars [4] = new BMW("z3","Diesel",15,false);
     

     for (Car car:cars){
         System.out.println(car.getNumberGear());}
    }
    
}
