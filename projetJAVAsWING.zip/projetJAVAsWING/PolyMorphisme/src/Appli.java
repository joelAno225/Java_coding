
public class Appli {
    public static void main (String[] args){
/*
   //Pomme p = new Pomme(40);
    Fruit f = new Pomme((40));
    ((Pomme)f).affichePoids();
    f.affiche();
  //le surcasting se automatiquement par la JvM
    f = new Orange(50);
    f.affiche();
    } */

//Utilisation des tableau (le surcasting permet aussi 
//l'insertion de selement dans le tableau 

     Fruit fruits[] = new Fruit[3];
     fruits[0] = new Pomme(40);
     fruits[1] = new Orange(400);
     fruits[2]=  new Pomme(100);   
     
     for (int i=0;i<fruits.length;i++){
            fruits[i].affiche();

            fruits[i].affichePoids();
      }
   }

}
