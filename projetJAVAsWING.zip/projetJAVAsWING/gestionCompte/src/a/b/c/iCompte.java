
package a.b.c;

public interface iCompte {

//on cree une application qui permet de verser retirer et consulté son solde
  public void verser(float mt);
  public void retirer(float mt);
  public void getSolde(); 
}
