
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class IO2 {
    public static void main(String[] args) throws IOException {
       
      File f = File("javaTXT.txt")
    }
    
}
