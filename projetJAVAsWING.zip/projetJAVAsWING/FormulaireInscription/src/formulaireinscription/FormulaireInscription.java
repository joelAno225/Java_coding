
package formulaireinscription;


public class FormulaireInscription {

    public static void main(String[] args) {
       
    }
    
}
